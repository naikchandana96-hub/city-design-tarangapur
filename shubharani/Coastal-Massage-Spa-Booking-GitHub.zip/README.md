# 🌊 Coastal Massage — Spa & Appointment Booking

A **Segment Tree + Interval Query based appointment booking system**  
designed for spa / massage centers to efficiently handle overlapping bookings.

## 🚀 Live Demo (GitHub Pages)
After enabling GitHub Pages, visit:
```
https://<your-username>.github.io/Coastal-Massage-Spa-Booking/
```

## 🧠 Algorithm Used
- Segment Tree with Lazy Propagation
- Interval Max Query
- Range Add Updates

## 📂 Project Structure
```
Coastal-Massage-Spa-Booking/
├── index.html
└── README.md
```

## 🛠 How to Deploy on GitHub Pages
1. Push this repository to GitHub  
2. Go to **Settings → Pages**
3. Source: `main` branch → `/root`
4. Save & refresh after 30 seconds

## ✨ Features
- Prevents overlapping appointments
- Capacity-based booking
- Hourly concurrency visualization
- Cancel & rebook support

---
Made for academic & portfolio use.
